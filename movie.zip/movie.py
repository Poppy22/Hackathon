M=[] #array for instances of the class Movie
class Movie():
    def __init__(self, name, genre, release_year, length, director, rating=0):
        self.name=name
        self.genre=genre
        self.release_year=release_year
        self.length=length  #in minutes
        self.rating=rating  #out of five stars
        self.director=director
        M.append(self)
    def get_info(self):  #prints information about an instance
        print ("Title",self.name)
        print ("It is a",self.genre, "movie.")
        print ("Directed by ",self.director, ".")
        print ("It takes ",self.length, "minutes.")
        if self.release_year>2016:
            print ("It will be released in", self.release_year)
        else:
            print ("Released in ",self.release_year, ".")
        if self.rating==0:
            print ("It is not rated yet.")
        else:
            print ("It was given ",self.rating, " stars.")

class Account():
    viewed_films = []
    saved_films = []
    def __init__(self, name, password, email, saved_films, viewed_films):
        self.name=name
        self.password=password
        self.email=email
        self.saved_films=saved_films
        self.viewed_films=viewed_films
    def get_info_saved_films(self):
        for i in range(len(self.saved_films)):
            j=search_all(self.saved_films[i])
            if j != -1:
                M[j].get_info()
                print("\n")
    def get_info_viewed_films(self):
        for i in range(len(self.viewed_films)):
            j=search_all(self.viewed_films[i])
            if j != -1:
                M[j].get_info()
                print("\n")

def add():   #creates a new instance
    genre=input("What genre is this movie? ")
    director=input("Who was it directed by? ")
    year=int(input("When was it/will it be released? "))
    length=int(input("How long does it take to watch this movie (in minutes)? "))
    rating=int(input("How good is it (out of 5)? Leave 0 if you don't know. "))

def search_all(Title):
    for i in range(len(M)):
        if Title==M[i].name:
            return i
    return -1

def search(Title, X=[]):
    for i in range(len(X)):
        if Title==X[i]:
            return i
    return -1

def afis(X=[]):
    print ("Your list now look like this:")
    for i in range(len(X)):
        print (X[i])

#example for an account
V=["Donnie Darko", "How Grinch stole Christmas", "J'ai tue ma mere", "Death Note"] #viewed movies
F=["Donnie Darko", "J'ai tue ma mere"]  #favourite movies
user=Account("Poppy", "bananaband19", "somewhere@yahoo.com", F, V)

#example instances for Movie
Movie("How Grinch stole Christmas", "comedy", 1998, 108, "Tim Batman", 4 )
Movie("Donnie Darko", "horror", 2002, 89, "Randal Jones", 5)
Movie("Twitdrama", "YA", 2016, 130, "Hayley Swen", 2)
Movie("Love story", "romance", 1980, 120, "Donn Tunn", 5)
Movie("Stranger me", "action", 2018, 98, "Ben Track")
Movie("J'ai tue ma mere", "drama", 2010, 98, "Xavier Smth", 5)
Movie("Death Note", "animation", 2014, 108, "Xin Zhao", 3)

#Some actions from which you can choose
print("What would you like to do?")
print ("0. Nothing")
print("1. View movie archive")
print ("2. View favourite movies list")
print ("3. View recently viewed movie list")
print ("4. Search for a movie")
print ("5. Add a new movie to your favourites")
print ("6. Delete a movie from your favourites")
op=int(input("Your choice: "))

R=[] #vector with recently deleted movies in order to recover them, just in case
if op==0: pass
elif op==1:
    for i in range(len(M)):
        print (i+1)
        M[i].get_info()
        print("\n")
elif op==2:
    user.get_info_saved_films()
elif op==3:
    user.get_info_viewed_films()
elif op==4:
    Title=input("Please introduce the movie title: ")
    i=search_all(Title)
    if i>=0:
        print ("Search results:")
        M[i].get_info()
    else:
        print ("Movie not found. Would you like to upload it?")
        x=input("Type yes if you want to upload a new movie. Type any key to exit this menu.")
        if x=="yes" or x=="Yes":
            add()
            Movie(Title, genre, year, length, director, rating)
            M[len(M)-1].get_info()
elif op==5:
    Title=input("Please introduce the movie title: ")
    i=search_all(Title)
    if i==-1:
        print ("This movie doesn't exist here.")
    else:
        i=search(Title, F)
        if i==-1:
            F.append(Title)
            afis(F)
        else:
            print ("It is already on the list.")
elif op==6:
    Title=input("Please introduce the movie title: ")
    i=search(Title, F)
    if i>=0:
        R.append(F[i])
        del F[i]
        afis(F)
    else:
        print ("Movie not found.")
